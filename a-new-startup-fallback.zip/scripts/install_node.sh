#!/bin/bash

#
# Install NodeJS 16
# This is Amazon Linux 2023 - but ...
# NodeJS 18 is not yet supported on AL2 (which is what we use in Cloud9): https://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/setting-up-node-on-ec2-instance.html
# So to keep things similar between the prod and dev environments just use NodeJS 16.

cd /home/ec2-user/node-website

curl -fsSL https://rpm.nodesource.com/setup_16.x | sudo bash -
yum update
yum install -y nodejs
npm -v
node -v